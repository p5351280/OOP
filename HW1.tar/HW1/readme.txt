Student ID : 404410053
Name : Shuo-En Chang

Description : 
	The program will show the Calendar of the month you want it to print out.
	In the program, it use Zeller's congruence to caculate the first weekday in the month.
	Ending the program just press Ctrl+C.
	You can input the year between 1901-2099, and the month between 1-12.
	Don't try to have a challenge on the program.

	In the driver program, you can test if the function get1stDayOfMonth is correct or not.
	Input the year and month, it will tell you the first Weekday in the month, and how many days are there in month.

Compiler command:
	g++ -o calendar.out calendar.cpp
	./calendar.out
